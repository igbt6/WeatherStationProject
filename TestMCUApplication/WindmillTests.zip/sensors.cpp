
#include "sensors.h"

/////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// /////////////////////////////////////////////// ///////////////////////////////////////////////

SENSORS::SENSORS():usbDebug(USBTX, USBRX),lcd(PTD7,PTE31,PTD6, PTC17,PTC16,PTC13,PTC12)// rs,rw,e,d4-d7
{

   
    lcd.printf("HELLO\n");
    #ifdef  MAX4070_ENABLED
    max4070= new MAX4070(MAX4070_PIN_ANALOG_IN ,1 /*4mv ->1mA*/);
    max4070Voltage= new MAX4070Voltage(MAX4070_PIN_ANALOG_IN_VOLTAGE ,1 );
    #endif
    #ifdef BMP180_ENABLED
    bmp180= new BMP180( BMP180_PIN_SDA, BMP180_PIN_SCL);
    bmp180->Initialize(64, BMP180_OSS_ULTRA_LOW_POWER); // 64m altitude compensation and low power oversampling
    #endif
    
#ifdef USB_DEBUG
     usbDebug.printf("AND GHERE_ALSO\r\n");
#endif
    msd = new  USBHostMSD("usb");
#ifdef USB_DEBUG
      usbDebug.printf(" HERERERRE\r\n");
#endif
    if (!msd->connect()) {
        #ifdef USB_DEBUG
        usbDebug.printf(" USB Flash drive not found.\r\n");
        #endif
    } else {
       
        fileCurrent= fopen("/usb/VOLTAGE_1.txt", "w"); //rewrite, or create
        if (fileCurrent) {
            #ifdef USB_DEBUG 
            usbDebug.printf("(/usb/pCurrent.txt)... sucess file-open!\r\n\r\n");
             #endif
            fprintf(fileCurrent, " LOG VOLTAGE [V] - VOLTAGE_1:\r\n INFO: Dane zapisywane sa co 0.5 sek.\r\n\r\n");
            fclose(fileCurrent);
            fileCurrent=NULL;
        } 
        #ifdef USB_DEBUG  
         else usbDebug.printf(" ... failed file-open (/usb/pCurrent.txt)!\r\n\r\n");
         #endif
        fileVoltage=fopen("/usb/VOLTAGE_2.txt", "w");
        if (fileVoltage) {
            #ifdef USB_DEBUG 
            usbDebug.printf("(/usb/pVoltage.txt)... sucess file-open!\r\n\r\n");
             #endif
            fprintf(fileVoltage, " LOG VOLTAGE [V]- VOLTAGE_2:\r\n INFO: Dane zapisywane sa co 0.5 sek.\r\n\r\n");
            fclose(fileVoltage);
            fileVoltage=NULL;
        } 
        #ifdef USB_DEBUG  
        else usbDebug.printf(" ... failed file-open (/usb/pVoltage.txt)!\r\n\r\n");
        #endif
    }

}

SENSORS::~SENSORS()
{
    if(fileCurrent!=NULL) {
        fclose(fileCurrent);
        fileCurrent=NULL;
    }
    if(fileVoltage!=NULL) {
        fclose(fileVoltage);
        fileVoltage=NULL;
    }
    
    delete max4070;
    delete max4070Voltage;
    delete bmp180;

}





void SENSORS:: measurement (void const* args)
{
    
   while(1) {
 #ifdef MAX4070_ENABLED
        max4070->readValueFromInput();
        results.MAX4070chargerCurrent=max4070->getResult();

        max4070Voltage->readValueFromInput();
        results.MAX4070chargerVoltage=max4070Voltage->getResult();
 #endif
 #ifdef BMP180_ENABLED       
        if (bmp180->ReadData( &results.BMP180temperature,&results.BMP180pressure)) {
        } else
        results.BMP180temperature=-999;
 #endif

    lcd.cls();
      lcd.printf("[A]\n");
        Thread::wait(333);
    }
}






void SENSORS::getResults (void const* args)
{
    while(1) {
        measPrintMutex.lock();
#ifdef USB_DEBUG
        #ifdef MAX4070_ENABLED
        usbDebug.printf("MAX4070_CurrentValue: %5.2f\r\n",results.MAX4070chargerCurrent);
        usbDebug.printf("MAX4070_VoltageValue: %5.2f\r\n",results.MAX4070chargerVoltage);
        #endif
#ifdef BMP180_ENABLED
        if(results.BMP180pressure!=-999&&results.BMP180temperature!=-999)
            usbDebug.printf("Pressure(hPa):   %5.2f\r\nTemperatureBMP180(C):   %5.2f\r\n", results.BMP180pressure, results.BMP180temperature);
        else
            usbDebug.printf("BMP180_ERROR\r\n");

#endif
#endif
        measPrintMutex.unlock();
        Thread::wait(500);
    }
}







int SENSORS::saveDataToUSB(void const* args)
{
    while(1) {
         // measPrintMutex.lock();
        
        
        if(!msd->connect()) {
#ifdef USB_DEBUG
            usbDebug.printf("ERROR!: USB Flash drive not found. is not connected or broken -> just try to connect it\r\n");
#endif
        } else {
            
            #ifdef USB_DEBUG
            usbDebug.printf("PENDRIVE IS CONNECTED\r\n");
            #endif
           
            if(!fileCurrent) {
                fileCurrent=fopen("/usb/VOLTAGE_1.txt", "a");
            } else {
                fprintf(fileCurrent,"%5.2f\r\n", results.MAX4070chargerCurrent);
                fclose(fileCurrent);
                fileCurrent=NULL;
            }
            if(!fileVoltage) {
                fileVoltage=fopen("/usb/VOLTAGE_2.txt", "a");
            } else {
                fprintf(fileVoltage,"%5.2f\r\n", results.MAX4070chargerVoltage);
                fclose(fileVoltage);
                fileVoltage=NULL;
            }
        } 
       //  measPrintMutex.unlock();
        Thread::wait(500);
    }
}


void SENSORS:: showError(void){
PwmOut r (LED_RED);
PwmOut g (LED_GREEN);
PwmOut b (LED_BLUE);


    r.period(0.001);
    g.period(0.001);
    b.period(0.001);

    while (true) {
        for (float i = 0.0; i < 1.0 ; i += 0.001) {
            float p = 3 * i;
            r = 1.0 - ((p < 1.0) ? 1.0 - p : (p > 2.0) ? p - 2.0 : 0.0);
            g = 1.0 - ((p < 1.0) ? p : (p > 2.0) ? 0.0 : 2.0 - p);
            b = 1.0 - ((p < 1.0) ? 0.0 : (p > 2.0) ? 3.0 - p : p - 1.0);
            wait (0.0025);
        }
    }
}
